# Lunar Unity Mobile Console

GitHub page:
https://github.com/SpaceMadness/lunar-unity-console

Wiki page:
https://github.com/SpaceMadness/lunar-unity-console/wiki

Asset store link:
https://www.assetstore.unity3d.com/#!/content/43800

Forum thread:
http://forum.unity3d.com/threads/lunar-mobile-console-high-performance-unity-ios-android-logger-built-with-native-platform-ui.347650/
