. $(dirname $0)/common.sh

disable_plugin