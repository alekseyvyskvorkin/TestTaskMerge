. $(dirname $0)/common.sh

enable_plugin