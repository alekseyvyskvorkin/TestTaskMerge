﻿public enum ItemType 
{
    None,
    Buildings,
    Plants
}
